#include <stddef.h>
#include <sys/types.h>
#include "types.h"
#include "riscv.h"
#include "fcntl.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "fs.h"
#include "memlayout.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "file.h"
#include "proc.h"

static int    argfd(int, int *, struct file **);

static int
argfd(int n, int *pfd, struct file **pf)
{
  int fd;
  struct file *f;

  if(argint(n, &fd) < 0)
    return -1;
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    return -1;
  if(pfd)
    *pfd = fd;
  if(pf)
    *pf = f;
  return 0;
}

uint64
sys_exit(void)
{
  int n;
  if(argint(0, &n) < 0)
    return -1;
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  if(argaddr(0, &p) < 0)
    return -1;
  return wait(p);
}

uint64
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

uint64
sys_mmap(void){
  int length;  //number of bytes to map
  int prot;  //indicates whether the memory should be mapped readable, writeable, and/or executable
  int flags; // will be MAP_SHARED or MAP_PRIVATE
  struct file *fd = filealloc();

  if (argint(1, &length) < 0 || argint(2, &prot) < 0 || argint(3, &flags) || argfd(4, 0, &fd))
      return -1;
  if (length % PGSIZE != 0 || (fd->writable == 0 && (prot & PROT_WRITE) && flags == MAP_SHARED))
      return -1;
  struct proc *p = myproc();
  uint64 addr = (1L << 37) + p->mmapsz;
  for (int i = 0; i < 16; i++){
      if (!p->vmas[i].valid) {
          p->vmas[i].valid = 1;
          p->vmas[i].addr = p->vmas[i].oaddr = addr;
          p->vmas[i].length = length;
          p->vmas[i].prot = prot;
          p->vmas[i].flags = flags;
          p->vmas[i].fd = fd;
          filedup(fd);
          p->mmapsz += length;
          return addr;
      }
  }
  return -1;
}

uint64 sys_munmap(void) {
    uint64 addr; int length;
    if (argint(1, &length) < 0 || argaddr(0, &addr) < 0)
        return -1;
    if (addr % PGSIZE != 0 || length % PGSIZE != 0)
        return -1;
    struct proc *p = myproc();
    for (int i = 0; i < 16; i++) {
        if (p->vmas[i].valid && ( addr == p->vmas[i].addr || (addr + length == p->vmas[i].addr + p->vmas[i].length))){
            for (int j = 0; j < length; j += PGSIZE) {
                if (walkaddr(p->pagetable, addr + j) == 0)
                    continue;
                if (p->vmas[i].flags == MAP_SHARED) {
                    begin_op();
                    ilock(p->vmas[i].fd->ip);
                    writei(p->vmas[i].fd->ip, 1, addr + j, addr + j - p->vmas[i].oaddr, PGSIZE);
                    iunlock(p->vmas[i].fd->ip);
                    end_op();
                }
                uvmunmap(p->pagetable, j + addr, 1, 1);
            }
            if (addr + length == p->vmas[i].addr + p->vmas[i].length)
                p->vmas[i].length = addr - p->vmas[i].addr;
            else {
                p->vmas[i].addr = addr + length;
                p->vmas[i].length -= length;
            }
            if (p->vmas[i].length == 0) {
                fileclose(p->vmas[i].fd);
                p->vmas[i].valid = 0;
            }
            return 0;
        }
    }
    return 0;
}
