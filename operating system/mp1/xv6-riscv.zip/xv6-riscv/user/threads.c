#include "kernel/types.h"
#include "user/setjmp.h"
#include "user/threads.h"
#include "user/user.h"
#define NULL 0


static struct thread* current_thread = NULL;
static int id = 1;
static jmp_buf env_st;
static jmp_buf env_tmp;


struct thread *thread_create(void (*f)(void *), void *arg){
    struct thread *t = (struct thread*) malloc(sizeof(struct thread));
    //unsigned long stack_p = 0;
    unsigned long new_stack_p;
    unsigned long new_stack;
    new_stack = (unsigned long) malloc (sizeof(unsigned long)*0x100);  //space
    new_stack_p = new_stack + 0x100*8-0x2*8;  //starting pos (auto update)
    t->fp = f;
    t->arg = arg;
    t->ID  = id;
    t->buf_set = 0;
    t->stack = (void*) new_stack;
    t->stack_p = (void*) new_stack_p;
    id++;
    return t;
}
void thread_add_runqueue(struct thread *t){
    //printf("add\n");
    if(current_thread == NULL){
        // TODO
        current_thread = t;
        current_thread->next = t;
        current_thread->previous = t;
    }
    else{
        // TODO
        t->previous = current_thread->previous;
        t->next = current_thread;
        current_thread->previous->next = t;
        current_thread->previous = t;
    }
}
void thread_yield(void){
    //printf("yield %d\n", current_thread->ID);
    // TODO
    int jmpval = setjmp(current_thread->env);
    if(jmpval != 0){
        return;
    }
    schedule();  
    dispatch();
}
void dispatch(void){
    //printf("dispatch\n");
    // TODO
    if(current_thread->buf_set == 0){  // first run
        // initialize
        int n = setjmp(env_tmp);
        if (n==0){
            //printf("init id = %d\n", current_thread->ID);
            env_tmp->sp = (unsigned long) current_thread->stack_p;
            current_thread->buf_set = 1;
            longjmp(env_tmp, 1);
        }
        current_thread->fp(current_thread->arg);
        thread_exit();
    }
    else{
        //longjmp to update context
        //printf("longjmp thread = %d\n", current_thread->ID);
        longjmp(current_thread->env, 1);
    }
}
void schedule(void){
    current_thread = current_thread->next;
    //printf("sche : current_thread = %d\n", current_thread->ID);
}
void thread_exit(void){
    //printf("%d exit\n", current_thread->ID);
    if(current_thread->next != current_thread){
        // TODO
        current_thread->next->previous = current_thread->previous;
        current_thread->previous->next = current_thread->next;
        free(current_thread);
        schedule();
        dispatch();
    }
    else{
        // TODO
        // Hint: No more thread to execute
        free(current_thread);
        current_thread = NULL;
        longjmp(env_st, 1);
    }
}
void thread_start_threading(void){
    //printf("start\n");
    // TODO
    int st = setjmp(env_st);
    if(st == 1){
        return;     
    }
    schedule();
    dispatch();
}