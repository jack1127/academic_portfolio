#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"

char* fmtname(char *path){
	static char buf[DIRSIZ+1];
  	char *p;

  	// Find first character after last slash.
  	for(p=path+strlen(path); p >= path && *p != '/'; p--)
    	;
  	p++;

  	// Return blank-padded name.
  	if(strlen(p) >= DIRSIZ)
  	  	return p;
  	memmove(buf, p, strlen(p));
  	memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
  	//printf("fn = %s\n", buf);
  	return buf;
}

int dfs(char *path, char *target, const int pid){
    int fd, exist = 0, exist_child = 0;
    char buf[512], *p;
    struct dirent de;
    struct stat st;
	if((fd = open(path, 0)) < 0){
    	fprintf(2, "ls: cannot open %s\n", path);
    	return exist;
  	}

  	if(fstat(fd, &st) < 0){
    	fprintf(2, "ls: cannot stat %s\n", path);
    	close(fd);
    	return exist;
  	}
	switch(st.type){
	case T_FILE:
		//printf("target = %s, yo\n",target);
		if(strcmp(fmtname(path), target) == 0){
			printf("%s, %s\n", path, target);
			printf("%d as Watson: %s\n", pid, path);
            exist = 1;
		}
	    break;

	case T_DIR:
	  	if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){
	      	printf("ls: path too long\n");
	      	break;
	    }

	    strcpy(buf, path);
	    p = buf+strlen(buf);
	    *p++ = '/';
	    while(read(fd, &de, sizeof(de)) == sizeof(de)){
	 		if (strcmp(de.name, ".") == 0 || strcmp(de.name, "..") == 0)
	        	continue;
	 		if(de.inum == 0)
	    		continue;
	      	memmove(p, de.name, DIRSIZ);
	      	p[DIRSIZ] = 0;
	      	if(stat(buf, &st) < 0){
	        	printf("ls: cannot stat %s\n", buf);
	        	continue;
	      	}
	      	exist_child = exist_child | dfs(buf, target, pid);
	    }
	    break;
	}
	close(fd);
    exist = exist | exist_child;
    return exist;
}


int main(int argc, char *argv[]){
	int pid, pfd[2], status, exist=0; //pipe
	char ans[1], buf[DIRSIZ+1];

	if(pipe(pfd) < 0){
		printf("failed to create pipe\n");
		return 0;
	}
	
	pid = fork();
    
    if (pid < 0){
    	return 0;
    }
	// child process
    else if(pid == 0){
    	close(pfd[0]);
    	
    	memmove(buf, argv[1], strlen(argv[1]));
  		memset(buf+strlen(argv[1]), ' ', DIRSIZ-strlen(argv[1]));
    	
    	exist = dfs(".", buf, getpid());

 		if(exist){
    		write(pfd[1], "y", 1);
    	}
        
    	else{
    		write(pfd[1], "n", 1);
    	}
    }
  
    // parent process 
    else{
    	close(pfd[1]);
    	read(pfd[0], ans, 1);
    	wait(&status);
    	printf("%d as Holmes: ", getpid()); 
    	if(strcmp(ans, "y") == 0){
    		printf("This is the evidence\n");
    	}
    	else if(strcmp(ans, "n") == 0){
    		printf("This is the alibi\n");
    	}
    }
  
    exit(0); 
} 