compile example:

python FA_hw3.py
90 100 110 1 0.05 0.30 250 100000


Note:
It might cost about 20 seconds, please wait.