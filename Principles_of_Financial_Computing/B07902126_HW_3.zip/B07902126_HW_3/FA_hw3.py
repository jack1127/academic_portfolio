import math
import numpy as np
from decimal import *

S, X, H, r, sigma, T, n= input().split()
S = Decimal(S)
X = Decimal(X)
H = Decimal(H)
r = Decimal(Decimal(r)/100)
sigma = Decimal(Decimal(sigma)/100)
T = int(T)
n = int(n)
#Stock price, strike price, barrier level, continuously compounded annual interest rate in percentage,
#annual volatility in percentage, time to maturity in years, number of time steps of the tree, bucket

dt = T/n
root_dt = Decimal(math.sqrt(dt))
h = math.floor(Decimal.ln(S/H)/Decimal(sigma*root_dt))

if (h<1 or h>n):
	print("h failure")
	exit(0)

lamda = Decimal(Decimal(math.log(S/H))/(h*sigma*root_dt))
#print("lamda = ", lamda)
Pu = Decimal(1/(2*lamda*lamda)) + Decimal(Decimal(r-sigma*sigma/2)*root_dt/Decimal(2*lamda*sigma))
#print("Pu = ", Pu)
Pd = Decimal(1/(2*lamda*lamda)) - Decimal(Decimal(r-sigma*sigma/2)*root_dt/Decimal(2*lamda*sigma))
#print("Pd = ", Pd)
Pm = 1-Pu-Pd
#print("Pm = ", Pm)

u = Decimal.exp(lamda*sigma*root_dt)
#print("u = ",u)

C = [0 for _ in range(2*n+2)]
for i in range(2*n+1):
	C[i] =  max(0, Decimal(X-S*(u**(n-i))))

D = [0 for _ in range(2*n+1)]

for i in range(n+h, 2*n+1):
	D[i] = C[i]

for j in range(n-1, -1, -1):
	for i in range(2*j+1):
		C[i] = Decimal(Pu*C[i] + Pm*C[i+1] + Pd*C[i+2])
		D[i] = Decimal(Pu*D[i] + Pm*D[i+1] + Pd*D[i+2])
	if (j+h <=2*j):
	 	D[j+h] = C[j+h] 

print(round(Decimal(D[0])/Decimal.exp(r*T),4))