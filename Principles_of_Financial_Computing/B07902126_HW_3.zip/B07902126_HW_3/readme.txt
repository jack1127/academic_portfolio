compile example:

python FA_hw3.py
100 95 90 5 25 1 100