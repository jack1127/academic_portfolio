sample input format:
"python FA_hw1.py" to compile
"100 100 5 30 1 41" to input information