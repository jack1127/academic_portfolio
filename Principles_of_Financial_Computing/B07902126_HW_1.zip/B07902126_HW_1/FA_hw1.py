import math
from decimal import Decimal, ROUND_UP, ROUND_HALF_UP

S, X, r, sigma, T, n = input().split()
S = Decimal(S)
X = Decimal(X)
r = Decimal(Decimal(r)/100)
sigma = Decimal(Decimal(sigma)/100)
T = Decimal(T)
n = int(n)
 #Stock price, strike price, continuously compounded annual interest rate in percentage, annual volatility in percentage, time to maturity in years, number of time steps of the tree
pp = Decimal(0) #put price
h = Decimal(0) #hedge ratio
r_hat = Decimal(r*T/n)

u = Decimal(math.exp(sigma*Decimal(math.sqrt(Decimal(T/n)))))
d = Decimal(math.exp(-sigma*Decimal(math.sqrt(Decimal(T/n)))))

R = Decimal(math.exp(r_hat))

p = Decimal((R-d)/(u-d))

#print(u,d,p)

price_leaf = []
tmp_price = Decimal(S*(u**n))
price_leaf.append(tmp_price)

for i in range(n):
	tmp_price = Decimal(tmp_price / u * d)
	price_leaf.append(tmp_price)

new_price_leaf = []
hedge_leaf = []

for i in price_leaf:
	if i-X > 0:
		new_price_leaf.append(Decimal(0))
	else:
		new_price_leaf.append(Decimal(1))

""" n^2 version
n2_list = []
pp_n2 = 0
n2_list=new_price_leaf.copy()
for i in range(n):
	for j in range(len(n2_list)-1):
		n2_list[j] = (n2_list[j]*p + n2_list[j+1]*(1-p))/R
	del n2_list[len(n2_list)-1]
	if i == n-2:
		print("pp n2 Cu, Cd =", n2_list)
		break
"""

pp = 0
tmpC = 1
for i in range(n+1):
	if i == 0:
		tmpC = 1
	elif i == 1:
		tmpC = n		
	else:
		tmpC = Decimal(tmpC*(n-i+1)/Decimal(i))
	#print(tmpC)
	pp += Decimal(new_price_leaf[i]*(p**(n-i))*((1-p)**(i))*tmpC)
	
pp /= (R**n)

pp2 = 0
tmpC = 1
m = n-1
for i in range(n):
	if i == 0:
		tmpC = 1
	elif i == 1:
		tmpC = m
	else:
		tmpC = Decimal(tmpC*(m-i+1)/Decimal(i))
	#print(tmpC)
	pp2 += Decimal(new_price_leaf[i]*(p**(m-i))*((1-p)**(i))*tmpC)
pp2 /= Decimal(R**m)

pp3 = 0
tmpC = 1
for i in range(n):
	if i == 0:
		tmpC = 1
	elif i == 1:
		tmpC = m
	else:
		tmpC = Decimal(tmpC*(m-i+1)/i)
	#print(tmpC)
	pp3 += Decimal(new_price_leaf[i+1]*(p**(m-i))*((1-p)**(i))*tmpC)
pp3 /= Decimal(R**m)


h = Decimal((pp2-pp3)/(Decimal(S*u)-Decimal(S*d)))

#print("Cu, Cd",pp2, pp3)

pp = Decimal(pp).quantize(Decimal('.0000'), ROUND_HALF_UP)
h = Decimal(h).quantize(Decimal('.0000'), ROUND_HALF_UP)
print(pp, h)
