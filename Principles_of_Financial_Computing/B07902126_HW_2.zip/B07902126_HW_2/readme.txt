sample:

python FA_hw2.py
100 95 5 30 1 100 100

>>>0.5184 -0.0400

First output element is "put price"
Second output element is "delta"