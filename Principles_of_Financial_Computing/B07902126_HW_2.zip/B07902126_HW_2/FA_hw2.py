import math
import numpy as np
from decimal import Decimal, ROUND_UP, ROUND_HALF_UP

S, X, r, sigma, T, n, k= input().split()
S = Decimal(S)
X = Decimal(X)
r = Decimal(Decimal(r)/100)
sigma = Decimal(Decimal(sigma)/100)
T = Decimal(T)
n = int(n)
k = int(k)
#Stock price, strike price, continuously compounded annual interest rate in percentage,
#annual volatility in percentage, time to maturity in years, number of time steps of the tree, bucket

r_hat = Decimal(r*T/n)

u = Decimal(math.exp(sigma*Decimal(math.sqrt(Decimal(T/n)))))
d = Decimal(math.exp(-sigma*Decimal(math.sqrt(Decimal(T/n)))))
R = Decimal(math.exp(r_hat))
p = Decimal((R-d)/(u-d))

Amax = [[0 for i in range(n+1)] for j in range(n+1)]
Amin = [[0 for i in range(n+1)] for j in range(n+1)]
A3 = [[[0 for i in range(n+1)] for j in range(n+1)] for k in range(k+1)]
C = [[0 for i in range(n+1)] for j in range(k+1)]
D = [0 for i in range(k+1)]


for j in range(n+1):
	for i in range(j+1):
		Amax[j][i] = (S*(1-u**(j-i+1))/(1-u) + S*(u**(j-i)) * d * ((1-d**i)/(1-d))) / (j+1)
		Amin[j][i] = (S*(1-d**(i+1))/(1-d) + S*(d**i) * u * (1-u**(j-i))/(1-u)) / (j+1)

		for m in range(k+1):
			A3[j][i][m] = Decimal((k-m)/k) * Decimal(Amin[j][i]) + Decimal(m/k) * Decimal(Amax[j][i])


for i in range(n+1):
	for m in range(k+1):
		if X - Decimal(A3[n][i][m]) > 0:
			C[i][m] = Decimal(1)
		else:
			C[i][m] = Decimal(0)

for j in range(n-1, -1, -1):
	#print("in loop :", j)
	for i in range(j+1):
		for m in range(k+1):
			a = Decimal(A3[j][i][m])
			Au = Decimal((((j+1)*a + S * Decimal((u**(j+1-i))) * Decimal((d**i))))/ (j+2))

			if Au < A3[j+1][i][0] :
				Cu = Decimal(C[i][0])
			elif Au > A3[j+1][i][k] :
				Cu = Decimal(C[i][k])
			else:
				for q in range(k):
					if A3[j+1][i][q] <= Au and A3[j+1][i][q+1] >= Au :
						l = q
						break
				x = Decimal((Au-Decimal(A3[j+1][i][l+1]))/(Decimal(A3[j+1][i][l]) - Decimal(A3[j+1][i][l+1])))
				Cu = Decimal(x * Decimal(C[i][l]) + (1-x) * Decimal(C[i][l+1])) #Linear interpolation
			
			Ad = Decimal(((j+1)*a + S * Decimal((u**(j-i))) * Decimal((d**(i+1))))/(j+2))


			if Ad < A3[j+1][i+1][0] :
				Cd = Decimal(C[i+1][0])
			elif Ad > A3[j+1][i+1][k] :
				Cd = Decimal(C[i+1][k])
			else:
				for q in range(k):
					if A3[j+1][i+1][q] <= Ad and A3[j+1][i+1][q+1] >= Ad :
						l = q
						break
				x = Decimal((Ad-Decimal(A3[j+1][i+1][l+1]))/(Decimal(A3[j+1][i+1][l]) - Decimal(A3[j+1][i+1][l+1])))
				Cd = Decimal(x * Decimal(C[i+1][l]) + (1-x) * Decimal(C[i+1][l+1])) #Linear interpolation
			
			if X-a > 0 :
				tmp = Decimal(1)
			else:
				tmp = Decimal(0)
			D[m] = Decimal(max(tmp, (p * Cu + (1-p) * Cd) * Decimal.exp(-r_hat)))
			delta = Decimal((Cu-Cd)/(S*u - S*d))
			
		for m in range(k+1):
			C[i][m] = D[m]

pp = Decimal(C[0][0]).quantize(Decimal('.0000'), ROUND_HALF_UP)
delta = Decimal(delta).quantize(Decimal('.0000'), ROUND_HALF_UP)

print(pp, delta)